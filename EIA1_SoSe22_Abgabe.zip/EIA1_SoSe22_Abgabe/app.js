// Diese Aufgabe wurde mithilfe dieser Gruppe erarbeitet: Aanya Khetarpal, Julia Befus, Paula Jordans, Pia Giovannelli und Havva Sümeyye Kilic //
const schwierigkeitsgrad = document.getElementById("schwierigkeitsgrad"); // const schwer nimmt Element Id "schwierigkeitsgard" aus HTML das Element raus
const spiel = document.getElementById("appspiel"); // ""
const ende = document.getElementById("appende"); // ""
var aktuellesArray;
// übung 1 durch array [] und objekt dekl. und angeben der 15 übungssätze//
var saetze = [
    {
        spsatz: ["¡", "Hola", "!"],
        desatz: ["Hallo", "!"] // und darstellung der einzelnen wörter in boxen zum anklicken später
    },
    {
        spsatz: ["Me ", "Llamo ", "Havva. "],
        desatz: ["Ich", "heiße", "Havva."]
    },
    {
        spsatz: ["Vivo ", "de Furtwangen. "],
        desatz: ["Ich wohne", "in Furtwangen."]
    },
    {
        spsatz: ["Tengo ", "21 ", "años. "],
        desatz: ["Ich bin", "21", "Jahre alt."]
    },
    {
        spsatz: ["Me ", "gustan ", "los gatos. "],
        desatz: ["Ich", "liebe", "Katzen."]
    },
    {
        spsatz: ["Soy ", "un estudiante. "],
        desatz: ["Ich", "bin Studentin."]
    },
    {
        spsatz: ["Estudio ", "en Furtwangen. "],
        desatz: ["Ich studiere", "in Furtwangen."]
    },
    {
        spsatz: ["Mi ", "color favorito ", "es ", "el púrpura. "],
        desatz: ["Meine", "Lieblingsfarbe", "ist", "lila."]
    },
    {
        spsatz: ["Tengo ", "dos hermanos. "],
        desatz: ["Ich habe", "zwei Geschwister."]
    },
    {
        spsatz: ["El nombre ", "de mi ", "mejor amiga ", "es Hilal. "],
        desatz: ["Meine", "beste Freundin", "heißt Hilal."]
    },
    {
        spsatz: ["Quiero ", "viajar ", "a España. "],
        desatz: ["Ich möchte", "nach", "Spanien", "reisen."]
    },
    {
        spsatz: ["España ", "es un pais ", "muy bonito. "],
        desatz: ["Spanien", "ist", "ein sehr schönes", "Land."]
    },
    {
        spsatz: ["Mi ciudad ", "favorita ", "en España ", "es Valencia. "],
        desatz: ["Meine Lieblingsstadt", "in Spanien", "ist", "Valencia."]
    },
    {
        spsatz: ["Valencia ", "es ", "un ciudad Portuaria. "],
        desatz: ["Valencia", "ist", "eine Hafenstadt."]
    },
    {
        spsatz: ["La capital ", "de España ", "es Madrid. "],
        desatz: ["Die Hauptstadt", "von Spanien ", "ist Madrid. "] // alle 15 übunssätze
    }
];
var i = 0;
var punkte = 0; // punkte var wird direkt als zahl 0 deklariert für Aufzählung später
var anzahldersaetze = 0; // das selbe für die anzahlsätze für zähler
var satz = null; // var satz wird hier als null deklariert und wird gebracuht um sätze zu zählen
var spsatzmix; // spanische sätze werden als var spsatzmix deklariert um damit später die sätze durchzumischen
function shuffleArray(array) {
    var currentIndex = array.length, // erstellen von drei var die abgespeichert werden später
    temporaryValue, // ""
    randomIndex; //""
    while (0 !== currentIndex) { // while-schleife, code läuft so lange durch bis array durchläuft
        randomIndex = Math.floor(Math.random() * currentIndex); //current = aktuell (Zahl) -> laufvariable
        currentIndex -= 1; // für laufvariable wenn index nicht gleich minus null ist
        temporaryValue = array[currentIndex]; // abspeichern:temporary value wird der wert am aktuellen laufenden array ab currentindex
        array[currentIndex] = array[randomIndex]; //random position von array eingefügt
        array[randomIndex] = temporaryValue; // abgespeicherter wert wird hier in random hinzugefügt (tauschen sozusagen)
    }
    return array; // array wird wieder ausgegeben
}
shuffleArray(saetze);
spiel.classList.add("hidden"); // da nur eine html seite, soll diese funktionen nicht aufgerufen werden während der übung der sätze alos versteckt bleiben bis funkction folgt
ende.classList.add("hidden"); //""
document.getElementById("leicht").addEventListener("click", function () {
    // element mit id deklariert in html leicht wird hinaus genommen und anklickbar gemacht -> "button funktion"
    anzahldersaetze = 5; // bei dem schwierigkeitsgrad leicht sollen jeweil 5 übungsätze angegeben werden
    schwierigkeitsgrad.classList.add("hidden");
    spiel.classList.remove("hidden"); // beim spiel wird klasse hidden entfernt
    neuersatz(); // neuer satz soll ausgegeben werden
});
document.getElementById("mittel").addEventListener("click", function () {
    // element mit id deklariert in html mittel wird hinaus genommen und anklickbar gemacht -> "button funktion"
    anzahldersaetze = 10; //  bei dem schwierigkeitsgrad leicht sollen jeweil 10 übungsätze angegeben werden
    schwierigkeitsgrad.classList.add("hidden");
    spiel.classList.remove("hidden");
    neuersatz();
});
document.getElementById("schwer").addEventListener("click", function () {
    // element mit id deklariert in html schwer wird hinaus genommen und anklickbar gemacht -> "button funktion"
    anzahldersaetze = 15; // bei dem schwierigkeitsgrad leicht sollen jeweil 15 übungsätze angegeben werden
    schwierigkeitsgrad.classList.add("hidden");
    spiel.classList.remove("hidden");
    neuersatz();
});
function wortclick(wort) {
    console.log(wort); // überprüfen in konsole
    if (wort == aktuellesArray[i]) { // i entspricht hier  als var (oben)
        document.getElementById("wörter").innerHTML += wort + " "; // die wörter, die richtig sind, erscheinen hier an dementsprechnde stelle
        i++; // oben wurde das wort überprüft nach anklicken und dann wird i um eins erhöht und nächste stelle wird überprüft 
    }
    else {
        alert("Erneut Versuchen!");
    }
}
function neuersatz() {
    document.getElementById("desatz").innerHTML = ""; // dokument nimmt element desatz aus html raus, damit der satz erscheint
    document.getElementById("spsatz").innerHTML = ""; // ""
    document.getElementById("wörter").innerHTML = ""; // die wörter, die richtig sind, erscheinen hier an dementsprechnde stelle
    if (satz == null)
        satz = 0; // (if) falls der durchlauf der arrays vorüber ist, wird der nächste Schritt der Punkteausgabe angegeben
    else
        satz = satz + 1; // (else) ansonsten muss der nächste satz kommen, falls array durchlauf fertig ist
    //aktuellesArray = saetze[satz].spsatz; // aktuelles array oben deklariert und zeile 156 für spanisch eingefügt
    document.getElementById("desatz").innerHTML = saetze[satz].desatz.join(" "); // join = array wird zusammengefügt in klammer wird nichts dazwischen gesetzt
    var spanischN = Array.from(saetze[satz].spsatz);
    aktuellesArray = spanischN;
    var spanischS = shuffleArray(saetze[satz].spsatz); // var spanisch wird aus array sätze den spanisch satz raus und wird abgespeichert richtige array
    console.log("Richtig:" + spanischN);
    console.log("Shuffled: " + spanischS);
    for (var i = 0; i < spanischS.length; i++) { // 
        let wort = document.createElement("span");
        wort.innerHTML = spanischS[i];
        wort.addEventListener("click", function () {
            wortclick(wort.innerHTML);
        });
        document.getElementById("spsatz").appendChild(wort);
    }
    document.getElementById("satz").innerHTML = satz + 1 + " / " + anzahldersaetze;
    if (satz == anzahldersaetze) {
        spiel.classList.add("hidden");
        ende.classList.remove("hidden");
        document.getElementById("endpunkte").innerHTML = punkte + " Punkte erreicht";
    }
}
// for-schleife für vergleihcsoperatoren der sätze hat leider nicht geklappt 
// hab mein bestes gegeben :)
//# sourceMappingURL=app.js.map