Mit dem Start von TypeScript werden wir hier in dieser kleinen Übungsrunde einmal eine Skripdatei erstellen, transpilieren, einbinden und ausführen.

Also:

1. Stellen Sie sicher, dass [NodejS](https://nodejs.org/) installiert ist und Sie die [Konfigurationsdatei tsconfig.json ](https://github.com/gabriel-rausch/EIA1-Material/blob/master/L06/tsconfig.json) heruntergeladen haben
2. Jetzt soll eine TypeScript-Datei erstellt werden
3. Die Datei enthält folgenden Code: `alert("Hallo Welt");`
4. Diese TS-Datei jetzt zu einer JS-Datei transpilieren (Buildaufgabe ausführen / Run Build Task)
5. Dann die JS-Datei in einer HTML-Datei einbinden und im Browser aufrufen
