EIA1 Logo:

https://pixabay.com/de/illustrations/internet-planeten-getränke-3116062/

[Pixabay License](https://pixabay.com/de/service/license/)

Freie kommerzielle Nutzung 
Kein Bildnachweis nötig