Mit diesen kleinen Übungen sollen die Inhalte der aktuellen Lektion wiederholt werden:

### Übung A:
In der Skript-Datei finden Sie eine Liste von Farbwerten. Bei Klick auf den Button im HTML-Dokument soll der Hintergrund (body) zunächst mit der Farbe eingefärbt werden, die an der ersten Stelle des Arrays steht. Wenn noch einmal auf den Button geklickt wird, dann soll die Farbe an der 2. Stelle des Arrays den Hintergrund einfärben. Bei wiederholtem Klick der 3. Farbwert usw...

### Übung B:

Sie haben es wahrscheinlich schon bemerkt: nach einigen Klicks wird der Hintergrund nicht weiter eingefärbt. Die Anwendung ist "am Ende" des Arrays angekommen. Eine Bedingung wäre zwar hilfreich, um wieder an den Anfang des Arrays mit Farbwerten zu springen, aber noch nicht Teil der bisherigen Lektionen. Ergänzen Sie also ganz einfach eigene Farben, möglichst in ganz unterschiedlicher Notation (Hex, RGB, ...), um die Anzahl der Farbwerte im Array zu erhöhen.